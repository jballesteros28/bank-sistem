"""add intentos_fallidos column to usuarios

Revision ID: 1d7ca2a4366e
Revises: 11de379f4069
Create Date: 2025-09-23 16:25:08.258981

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision: str = '1d7ca2a4366e'
down_revision: Union[str, Sequence[str], None] = '11de379f4069'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.add_column(
        "usuarios",
        sa.Column("intentos_fallidos", sa.Integer(), nullable=False, server_default="0")
    )


def downgrade() -> None:
    op.drop_column("usuarios", "intentos_fallidos")
