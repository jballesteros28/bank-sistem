"""add reset_password_tokens table

Revision ID: 11de379f4069
Revises: 183344fdca31
Create Date: 2025-09-19 11:21:38.061305

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa
from datetime import datetime


# revision identifiers, used by Alembic.
revision: str = '11de379f4069'
down_revision: Union[str, Sequence[str], None] = '183344fdca31'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.create_table(
        "reset_password_tokens",
        sa.Column("id", sa.Integer(), primary_key=True, autoincrement=True, index=True),
        sa.Column("usuario_id", sa.Integer(), sa.ForeignKey("usuarios.id", ondelete="CASCADE"), nullable=False),
        sa.Column("token", sa.String(length=255), nullable=False, unique=True, index=True),
        sa.Column("expiracion", sa.DateTime(), nullable=False, default=datetime.utcnow),
        sa.Column("intentos", sa.Integer(), nullable=False, server_default="0"),
        sa.Column("usado", sa.Boolean(), nullable=False, server_default=sa.text("false")),
    )


def downgrade() -> None:
    op.drop_table("reset_password_tokens")
