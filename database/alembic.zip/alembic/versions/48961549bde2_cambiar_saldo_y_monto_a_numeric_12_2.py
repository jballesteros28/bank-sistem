"""cambiar saldo y monto a NUMERIC(12,2)

Revision ID: 48961549bde2
Revises: 1d7ca2a4366e
Create Date: 2025-09-25 13:03:17.340638

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision: str = '48961549bde2'
down_revision: Union[str, Sequence[str], None] = '1d7ca2a4366e'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    # 🔹 Modificar columnas a NUMERIC(12,2)
    op.alter_column("cuentas", "saldo",
                    type_=sa.Numeric(12, 2),
                    existing_nullable=False,
                    server_default="0")

    op.alter_column("transacciones", "monto",
                    type_=sa.Numeric(12, 2),
                    existing_nullable=False)


def downgrade() -> None:
    # 🔹 Revertir a FLOAT (si fuera necesario)
    op.alter_column("cuentas", "saldo",
                    type_=sa.Float(),
                    existing_nullable=False,
                    server_default="0.0")

    op.alter_column("transacciones", "monto",
                    type_=sa.Float(),
                    existing_nullable=False)